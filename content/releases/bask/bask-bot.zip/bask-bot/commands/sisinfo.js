const { MessageEmbed } = require("discord.js");

const os = require('os');

module.exports = {
    name: "sisinfo",
    aliases: ["sys"],
    cooldown: 10}

module.exports.execute = async (client, message, args, channel) => {

    let arch = os.arch();
    let platform = os.platform();
    let NodeVersion = process.version;
    let cores = os.cpus().length;
    
const stats = new Discord.MessageEmbed()
    .setTitle(`System Information of Bask`)
    .setColor('BLUE')
    .addField('Architecture', `${arch}`, true)
    .addField('Platform', `${platform}`, true)
    .addField('Node-Version', `${NodeVersion}`, true)
    .addField('Cores', `${cores}`, true)
    .setTimestamp()
    channel.send(stats);
}