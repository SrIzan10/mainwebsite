const { LOCALE, PRUNING } = require("../util/EvobotUtil");
//const i18n = require("i18n");
//i18n.setLocale(LOCALE);

module.exports = {
  name: 'ping',
  //callback: (message, arguments, text, client) => 
  execute(message){
    message.reply('Calculando ping...').then(resultMessage => {
      const ping = resultMessage.createdTimestamp - message.createdTimestamp

      resultMessage.edit('Pong! :ping_pong: Mi latencia es: ${ping}, La latencia de la API de Discord: ${msg.channel.ws.ping}');
    })
  }
}
