status=$?
## run date command ##
cmd="timeout 5s node index.js"
$cmd
## get status ##
status=$?
## take some decision ## 
[ $status -eq 0 ] && echo "$cmd command was successful" || echo "$cmd failed"